<?php

namespace App\Http\Controllers;

use App\Models\userComp;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use function PHPUnit\Framework\isNull;
use function PHPUnit\Framework\returnSelf;

class UserCompController extends Controller
{
    function validateDetails(Request $req)
    {
       
            if($req->hasFile('document1') || $req->hasFile('document2'))
            {
                $validFile = $this->FileExtVal($req);
                if($validFile == true)
                {
                    session()->pull('Complaint');
                    return redirect('NewComplaint')->with(['Status'=>'Your Complaint Registered Successfully.']);
                }
                else{
                    return redirect()->back()->withInput($req->input())->with(['FileError' => $validFile]);
                }
            }else{
                $ID = $this->GenerateID($req);
                $Status = $this->SendDetails($req,$pathDoc2="null",$pathDoc2="null",$ID);
                if($Status){return redirect('NewComplaint')->with(['Status'=>'Your Complaint Registered Successfully.']);}
            }   
    }
    function FileExtVal($req)
    {
        
        $file1 = $req->file('document1');
        $file2 = $req->file('document2');
        $fileExt1 = $file1->getClientOriginalExtension();
        $fileExt2=null;
        $FileError = NULL;
        $FileSizeErr = null;
        $doc1 = false;
        $doc2 = false;
        if ($fileExt1 == "pdf" || $fileExt1 == "doc" || $fileExt1 == "docx") {
            if ($file1->getSize() > 5242880) {
                $FileSizeErr =  "Document 1 size should less then 5MB";
            }
        } else {
            $FileError = "Document 1 must be of pdf/doc/docx extension only!!!";
            $doc1 = true;
        }

        if(is_null($file2)){}     
        else{
            
            $fileExt2 = $file2->getClientOriginalExtension();
            
            if ($fileExt2 == "pdf" || $fileExt2 == "doc" || $fileExt2 == "docx") {
                if ($file2->getSize() > 5242880) {
                    $FileSizeErr =  "Document 2 size should less then 5MB";
                }
            } else {
                $FileError .= "Document 2 must be of pdf/doc/docx extension only!!!";
                $doc2 = true;
            }
        }

        if ($doc1 && $doc2) {
            $FileError =  "Both Document must be of pdf/doc/docx extension only!!!";
        }
        if ($FileError == NULL) {
            if($FileSizeErr == null){
                if($this->StoreFiles($req,$fileExt1,$fileExt2)){return true;}
                else{
                    $FileError = "There was a problem while uploading your files please try again in few minutes"; 
                    return $FileError;
                }
            }
            else{
                return $FileSizeErr;
            }
        }
        else{
            return $FileError;
        }
        
    }

    function StoreFiles($req,$fileExt1,$fileExt2)
    {
        $ID = $this->GenerateID($req);
       $pathDoc1 = $req->file('document1')->storeAs('documents',$ID.'.'.$fileExt1);

       if($req->hasFile('document2'))
       {
           $pathDoc2 = $req->file('document2')->storeAs('documents',$ID.'.'.$fileExt2);
       }
      
       $Data = $this->SendDetails($req,$pathDoc1,$pathDoc2,$ID);

       return $Data; 
    }

    function SendDetails($req,$pathDoc1,$pathDoc2,$ID)
    {
        define("NA","NOT PROVIDED");
        try
        {
            $usercomp = new userComp();
            if(session()->has('Email'))
            {
                $usercomp->foreignEmail = $req->session()->get('Email');
            }else{
                return redirect()->back();
            } 
            $usercomp->Complaint_ID = $ID;
            $usercomp->ComplaintType = $req->complaintType;
            $usercomp->ComplaintCategory = $req->complaintCategory;
            $usercomp->SubCategory = $req->subCategory;
            $usercomp->AuthDept = $req->AuthDept;
            $usercomp->ComplaintNature = $req->complaintNature;
            $usercomp->District = $req->district;
            $usercomp->City = $req->city;
            $usercomp->Pincode = $req->pincode;
            $usercomp->ReferenceNo = $req->refNo;
            $usercomp->ComplaintDetails = $req->complaintDetails;
            if($req->hasfile('document1'))
            {
                $usercomp->Doc1FileName = $pathDoc1;
            }else{ $usercomp->Doc1FileName = NA;}
            if($req->hasFile('document2'))
            {
                $usercomp->Doc2FileName = $pathDoc2;
            }
            else{ $usercomp->Doc2FileName = NA;}
            $usercomp->ComplaintDate = $req->complaintDate;
            $usercomp->save();
            return true;

        }
        catch (Exception $error)
        {
            return $error;
        }
    }
    function GenerateID($req)
    {
        $ID = NULL;
        $IDCount  = DB::table('UserComplaints')->select('Complaint_ID')->pluck('Complaint_ID');
        foreach($IDCount as $var){
            $ID = $var;
        }
        if($ID == ''){
            $ID = "100000";
        }
        else{
            $ID = (int)$ID + 1;
        }
        return $ID;        
    }
}
