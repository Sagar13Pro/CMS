<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
class UserLogin extends Controller
{
    function Userlogin(Request $req)
    {
        $MailExists = $this->getMailCount($req);
       if($MailExists){
            if ($req->pass == Crypt::decryptString($MailExists)) {
                $userName = $this->getUserName($req);
                $req->session()->put('userName',$userName);
                session(['Email' => $req->email]);
                session()->regenerate();
                return redirect('Dashboard');
            } else {

                return redirect()->back()->with(["InvalidCre" => 'The Email and/or Password Is Invalid']);
            }

       } else {
           return redirect()->back()->with(['InvalidCre' => "The Email Doesn't Match With Our Records"]);
       }
    }
    function getMailCount($req)
    {
        $MailCount = DB::table('users')->select("Email")->where('Email',$req->email)->count();
        if($MailCount == 1)
        {
            $user = DB::table('users')->select("Password")->where('Email', $req->email)->get();
            foreach ($user as $item) {
                $userPass = $item->Password;
            }
            return $userPass;
        }

        return false;
    }

    function getUserName($req)
    {
        $usersCount = DB::table('users')->select('userName')->where('Email',$req->email)->count();
        if($usersCount == 1)
        {
            $users = DB::table('users')->select('userName')->where('Email', $req->email)->get();
            foreach($users as $item)
            {
                $userNames = $item->userName;
            }
            return $userNames;
        }
    }
}
