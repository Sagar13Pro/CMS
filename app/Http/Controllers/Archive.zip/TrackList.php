<?php

namespace App\Http\Controllers;

use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class TrackList extends Controller
{
    function FetchComplaints()
    {
       try{

           $table = DB::table('UserComplaints')->select('*')->where('foreignEmail',session()->get('Email'))->get();

       }
       catch (Exception $error)
       {
           return redirect('UserCompList');
       }

       return view('user.ComplaintList',['Details' => $table ]);
    }

    function FetchDetails($id)
    {
        try{

            $table = DB::table('UserComplaints')->select('*')->where([
                ['foreignEmail',session()->get('Email')],
                ['Complaint_ID',$id]
                ])->get();
 
        }
        catch (Exception $error)
        {
            return redirect('UserCompList');
        }

  
        return response()->json(['success'=>true,'List'=>$table]);
    }

    function TrackComplaint(Request $request)
    {
        dd($request->all());
    }
}
