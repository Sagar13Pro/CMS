<!DOCTYPE html>
<html lang="en">

<head>
	<title>User Panel</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="images/icons/favicon.ico" />
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
	<!--script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script!-->
	<link rel="stylesheet" type="text/css" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" crossorigin="anonymous">
	<style>
		li.list-group-item{
			border: 3px solid red;
		}
	</style>
</head>

<body>

	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<div class="login100-form-title" style="background-image: url(images/bg-01.jpg);">
					<span class="login100-form-title-1">
						Sign Up
					</span>
				</div>
				@if(session('Refresh'))
					<div class="alert alert-danger" style="margin:7px auto;width:70%;"><strong>Alert!</strong>{{session('Refresh')}}</div>
				@endif
				<form class="login100-form validate-form" action="RegisterData" method="post">
					@csrf
					<div class="wrap-input100 validate-input m-b-26" data-validate="User name is required">
						<span class="label-input100">Name <strong>*</strong></span>
						<input class="input100" type="text" name="_UserName" placeholder="Enter User Name" value="{{ old('_UserName') }}">
						<span class="focus-input100"></span>
					</div>
					@error('_UserName')
					<span class="alert alert-danger"> {{$message}} </span>
					@enderror

					<div class="wrap-input100 validate-input m-b-26" data-validate="Email is required">
						<span class="label-input100"> Email <strong>*</strong></span>
						<input class="input100" type="email" name="_Email" placeholder="Enter Your Email" value="{{ old('_Email') }}">
						<span class="focus-input100"></span>
					</div>
					@error('_Email')
					<span> {{$message}} </span>
					@enderror

					<div class="wrap-input100  m-b-26" data-validate="Mobile No. is required">
						<span class="label-input100"> Mobile No.<strong>*</strong></span>
						<input class="input100" type="number" name="_Mobile" placeholder="Enter Your Mobile No." value="{{ old('_Mobile') }}">
						<span class="focus-input100"></span>
					</div>
					@error('_Mobile')
					<span class="alert alert-danger">{{$message}}</span>
					@enderror

					<div class="wrap-input100 validate-input m-b-18" data-validate="Password is required">
						<span class="label-input100">Password <strong>*</strong></span>
						<input class="input100" id="PasswordShow" onfocusin="FocusItem()" onfocusout="RemoveItem()" type="password" name="_Passwd" placeholder="Enter password">
						<span class="eyeIcon"><i class="fas fa-eye" onclick="ShowPasswd()"></i></span>
						<span class="focus-input100"></span>
					</div>
					@error("_Passwd")
					<span class="alert alert-danger">{{ ($message) }}</span>
					@enderror
					<ul id="ListPopOn" class="list-group list-group-flush" style="display: none;">
						<li class="list-group-item addon		">
							<span class="lower-case">
								<i class="fas fa-circle-notch" aria-hidden="true"></i>&nbsp;LowerCase
							</span>
						</li>
						<li class="list-group-item">
							<span class="upper-case">
								<i class="fas fa-circle-notch" aria-hidden="true"></i>&nbsp;UpperCase
							</span>
						</li>
						<li class="list-group-item">
							<span class="number-digits">
								<i class="fas fa-circle-notch" aria-hidden="true"></i>&nbsp;Number (0-9)
							</span>
						</li>
						<li class="list-group-item">
							<span class="special-characters">
								<i class="fas fa-circle-notch" aria-hidden="true"></i>&nbsp;Special Characters
							</span>
						</li>
						<li class="list-group-item">
							<span class="AtLeast-Eight">
								<i class="fas fa-circle-notch" aria-hidden="true"></i>&nbsp;At Least 8 Char
							</span>
						</li>
					</ul>

					<div class="wrap-input100 validate-input m-b-18" data-validate="Confirm Password is required">
						<span class="label-input100">Confirm Password <strong>*</strong></span>
						<input class="input100" id="CpasswordShow" oninput="MatchPasswd()" type="password" name="_Cpasswd" placeholder="Confirm password">
						<span class="eyeIcon"><i aria-hidden="true" class="fas fa-eye" onclick="ShowCpasswd()"></i></span>
						<span class="focus-input100"></span>
						@if(session('Error'))
						<div class="alert alert-danger">
							<strong>Alert!</strong> {{session('Error')}}
						</div>
						@endif
					</div>
					<span id="MatchPass" class="alert"></span>
					<div class="container-login100-form-btn">
						<button class="login100-form-btn">
							Register
						</button>
					</div>

					<div class="flex-sb-m w-full p-b-30">
						<div class="AlreadyReg">
							Already Registered?&nbsp;Sign In<a href="UserLogin" class="txt1">&nbsp;here</a>
						</div>
					</div>



				</form>
			</div>
		</div>
	</div>

	<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
	<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
	<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
	<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
	<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
	<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
	<!--===============================================================================================-->
	<script src="js/main.js"></script>
	<script type="text/javascript" src="js/FunctionScript.js"></script>

</body>

</html>