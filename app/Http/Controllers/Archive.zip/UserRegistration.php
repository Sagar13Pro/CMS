<?php

namespace App\Http\Controllers;
use App\Models\User;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;

class UserRegistration extends Controller
{
    function Main(Request $req)
    {
        $validateData = $req->validate([
            '_UserName' => "required|min:6|max:15",
            '_Email' => "required",
            '_Mobile' => "required|min:10|max:10",
            '_Passwd' => "required|min:8"
        ]);
        if($this->MatchPassword($req)){
            if($this->SendData($req)){return view('user.UserLogin');}
            else{return redirect()->back()->withInput($req->all())->with(["Refresh" => "The Email or Mobile No. Already exists in our Records"]);}
        }else{
            return redirect()->back()->withInput($req->all())->with(["Error"=>"Password Doesn't Matched"]);
        }
    }

    function MatchPassword($req)
    {
        if($req->_Passwd == $req->_Cpasswd){ return true; }
        else{ return false; }
    }
    
    function SendData($req)
    {
        try{
            $userTable = new User();

            //Insertind data to Database
            $userTable->UserName = strtoupper(trim($req->_UserName));
            $userTable->Email = strtolower(trim($req->_Email));
            $userTable->MobileNO = $req->_Mobile;
            $userTable->Password = Crypt::encryptString($req->_Passwd);
            $userTable->save();
            return true;
        }
        catch (Exception $error)
        {
            dd($error);
            return false;
        }
    }
}
